ECE 3300 Lab 1 – Switch ↔ LED Interface

Members: Jetts Crittenden & Evan Tram

Objective: Build a Verilog module on the Digilent Nexys A7-100T that reads 16 switches and drives 16 LEDs. Learn about HDL I/O mapping, constraints files, synthesis, and FPGA programming.

https://youtu.be/MI8Awt-k5zA?si=hjOYX5ULnT2zMsoa
