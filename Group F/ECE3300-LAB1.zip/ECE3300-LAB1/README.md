Lab 1: Switch to LED Interface
Members: Changwe Musonda & Clay Kim
Description: We learnt how to a Verilog module on the Diligent Nexys A7-100T that reads 16 switches and drives 16 LEDs. We also learnt HDL I/O mapping, constraint files, synthesis, and FPGA programming
