# ECE3300-Lab2-GroupN
Lab 2 4x16 Decoder Design on Nexys A7-100T FPGA

Members: Daniel Mondragon and Kobe Aquino

Lab Objective: For this we will design, simulate, and implement a 4-to-16 decoder with an enable input. When
enabled, exactly one of 16 outputs goes HIGH based on the 4-bit input; when disabled, all
outputs are LOW.
