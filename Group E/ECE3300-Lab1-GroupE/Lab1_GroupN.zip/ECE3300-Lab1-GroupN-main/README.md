# ECE3300-Lab1-GroupN
Lab 1 Switch &lt;-> LED Interface

Members: Daniel Mondragon and Kobe Aquino

Lab Objective: We built a Verilog module on the Digilent Nexys A7-100T that reads 16 switches and drives 16 LEDs.
By doing so, we learned about HDL (hardware description language) I/O mapping, constraints files, synthesis, and FPGA programming.
