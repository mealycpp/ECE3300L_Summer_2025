Lab 2 : 4×16 Decoder Design on Nexys A7-100T FPGA

Group I: Julio Flores and Victor Perez

Lab Objective: The objective of this lab is to design and implement a 4 to 16 decoder with an enable input. This lab will utilize gate level structural coding and behavioral coding in verilog along with using Vivado resources such as testbench for self-checking and timing reports. Finally implementing this code into the Nexys A7-100T FPGA board for a physical demonstration of the 4 to 16 decoder. 
